# Finalist Results Table

Auto-generated from 14 finalist runs.
Lower is better for JSD, Wasserstein, and MMD.

| run_name | model | prompt | tau | seed | n | JSD | Wass(h) | MMD | Gnd% | Ung% |
|---|---|---|---|---|---|---|---|---|---|---|
| finalist_qwen_qwen3_5_2b_P2_V1_t1.1_s123 | Qwen/Qwen3.5-2B | P2_V1 | 1.1 | 123 | 108 | 0.4062 | 3.13 | 0.06530 | 57.4 | 14.8 |
| finalist_qwen_qwen3_5_2b_P2_V1_t1.1_s42 | Qwen/Qwen3.5-2B | P2_V1 | 1.1 | 42 | 108 | 0.4069 | 3.06 | 0.06842 | 64.8 | 10.2 |
| finalist_qwen_qwen3_5_2b_P2_V1_t0.9_s123 | Qwen/Qwen3.5-2B | P2_V1 | 0.9 | 123 | 108 | 0.4400 | 3.13 | 0.07826 | 71.3 | 5.6 |
| finalist_qwen_qwen3_5_2b_P2_V1_t0.9_s42 | Qwen/Qwen3.5-2B | P2_V1 | 0.9 | 42 | 108 | 0.4286 | 3.06 | 0.07958 | 73.1 | 3.7 |
| finalist_qwen_qwen3_5_2b_P2_V1_t0.7_s42 | Qwen/Qwen3.5-2B | P2_V1 | 0.7 | 42 | 108 | 0.4688 | 3.06 | 0.09662 | 86.1 | 5.6 |
| finalist_qwen_qwen3_5_2b_P2_V1_t0.7_s123 | Qwen/Qwen3.5-2B | P2_V1 | 0.7 | 123 | 108 | 0.4605 | 3.13 | 0.09672 | 80.6 | 2.8 |
| finalist_qwen_qwen2_5_3b_instruct_P0_V0_t1.1_s42 | Qwen/Qwen2.5-3B-Instruct | P0_V0 | 1.1 | 42 | 108 | 0.4942 | 3.06 | 0.10878 | 64.8 | 8.3 |
| finalist_qwen_qwen2_5_3b_instruct_P0_V0_t1.1_s123 | Qwen/Qwen2.5-3B-Instruct | P0_V0 | 1.1 | 123 | 108 | 0.5929 | 3.13 | 0.10897 | 66.7 | 3.7 |
| finalist_qwen_qwen2_5_3b_instruct_P0_V0_t0.9_s42 | Qwen/Qwen2.5-3B-Instruct | P0_V0 | 0.9 | 42 | 108 | 0.5319 | 3.06 | 0.11028 | 70.4 | 8.3 |
| finalist_qwen_qwen3_5_2b_P2_V1_t0.5_s42 | Qwen/Qwen3.5-2B | P2_V1 | 0.5 | 42 | 108 | 0.4605 | 3.06 | 0.11397 | 85.2 | 1.9 |
| finalist_qwen_qwen2_5_3b_instruct_P0_V0_t0.5_s42 | Qwen/Qwen2.5-3B-Instruct | P0_V0 | 0.5 | 42 | 108 | 0.5487 | 3.06 | 0.11589 | 69.4 | 9.3 |
| finalist_qwen_qwen3_5_2b_P2_V1_t0.5_s123 | Qwen/Qwen3.5-2B | P2_V1 | 0.5 | 123 | 108 | 0.4239 | 3.13 | 0.11744 | 86.1 | 1.9 |
| finalist_qwen_qwen2_5_3b_instruct_P0_V0_t0.9_s123 | Qwen/Qwen2.5-3B-Instruct | P0_V0 | 0.9 | 123 | 108 | 0.6015 | 3.13 | 0.11780 | 61.1 | 7.4 |
| finalist_qwen_qwen2_5_3b_instruct_P0_V0_t0.5_s123 | Qwen/Qwen2.5-3B-Instruct | P0_V0 | 0.5 | 123 | 108 | 0.5233 | 3.13 | 0.12106 | 75.9 | 7.4 |
